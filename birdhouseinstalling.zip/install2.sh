
#!/bin/bash

echo "full install birdhouse"

sudo mkdir /mnt/USBdrive

echo "update pi"
sudo apt-get update

echo "upgrade pi"
sudo apt-get upgrade

echo "installing apache2 and sqlite"
sudo apt-get install apache2 sqlite
sudo service apache2 restart

echo "installing owncloud"
#install PHP
sudo apt-get install php7.3 php7.3-gd php7.3-sqlite3 php7.3-curl libapache2-mod-php

#install SMB Client
sudo apt-get install smbclient

#PHP extentions needed to use owncloud
sudo apt-get install php7.3-mysql php7.3-mbstring php7.3-gettext php7.3-intl php7.3-redis php7.3-imagick php7.3-igbi$

#register owncloud trusted key
wget -nv https://download.owncloud.org/download/repositories/production/Debian_9.0/Release.key -O Release.key

sudo apt-key add - < Release.key

#add the official owncloud package repository to raspberian
echo 'deb http://download.owncloud.org/download/repositories/production/Debian_9.0/ /' > /etc/apt/sources.list.d/own$

apt-get update

#enable the apache mod_rewrite module
sudo a2enmod rewrite

#install Maria Database
sudo apt install mariadb-server mariadb-client

#configure the database and user
mysql -u root -p

#install owncloud
sudo apt install owncloud-files

#edit the Apache default site cinfiguration file
cp 000-default.conf /etc/apache2/sites-enabled/000-default.conf

#restart apache
sudo systemctl restart apache2

echo "replacing rc.local"
cp rc.local /etc

